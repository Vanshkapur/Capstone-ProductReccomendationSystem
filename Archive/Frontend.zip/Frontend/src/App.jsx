import React from "react";
import StoreProductRecommender from "./components/StoreProductRecommender";
import "./App.css";

function App() {
  return (
    <div className="App">
      <StoreProductRecommender />
    </div>
  );
}

export default App;
